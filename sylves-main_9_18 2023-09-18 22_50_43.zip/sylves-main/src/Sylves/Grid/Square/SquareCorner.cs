﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sylves
{
    public enum SquareCorner
    {
        DownRight,
        UpRight,
        UpLeft,
        DownLeft,
    }
}
