﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sylves
{
    public enum SquareDir
    {
        Right = 0,
        Up = 1,
        Left = 2,
        Down = 3,
    }
}
