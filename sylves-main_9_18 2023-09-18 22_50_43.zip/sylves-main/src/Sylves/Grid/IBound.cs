﻿namespace Sylves
{
    public interface IBound
    {

    }
}
