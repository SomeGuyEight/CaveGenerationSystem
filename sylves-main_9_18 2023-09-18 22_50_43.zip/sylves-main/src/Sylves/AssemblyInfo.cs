﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Sylves.Test")]

