# Modifiers

<style>
.grid-thumb {width: 200px; min-width: 200px; height: 200px; }
</style>

Modifier grids let you customize an existing grid by systematically changing it in some way.

[!include[](_modifiers_table.md)]