# Tutorials
* [Langton](langton.md)
* [Paint](paint.md)

There's also [online demos](https://boristhebrave.itch.io/sylves-demos) with [source](https://github.com/BorisTheBrave/sylves-demos/) giving even more examples.